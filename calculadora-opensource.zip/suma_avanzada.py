def suma_avanzada(lista):
    return sum(lista)